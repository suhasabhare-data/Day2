print('this is file p1')

def funName(username, age = 0):
    print('username',username)
    print('age',age)

# funName('ARC')


if __name__ == '__main__':
    print('this is main const')
    funName(username='ARC')